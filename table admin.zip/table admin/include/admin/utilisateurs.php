<div id="admin-art-list">

    <div class="admin-art-list-title">

        <div class="title title-admin-user">
            <img src="maquette\Icon awesome-users-cog.svg" alt="">
            <h2>Gestion des utilisateurs</h2>
        </div>

        <form>

            <div class="search-bar">
                <input type="text" placeholder="Rechercher">
            </div>

        </form>

    </div>

    <div class="admin-table user-table">
        <table>
            <thead>
                <tr class="admin-table-head">
                    <th class="column1">#Id</th>
                    <th class="column2">Nom</th>
                    <th class="column3">Prénom</th>
                    <th class="column4">Mail</th>
                    <th class="column5">date d'inscription</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="column1">#100</td>
                    <td class="column2">Richard</td>
                    <td class="column3">Jean-Pierre</td>
                    <td class="column4">jean-pierre@richard.fr</td>
                    <td class="column5">12/12/2020</td>
                </tr>
            </tbody>
        </table>
    </div>


</div>